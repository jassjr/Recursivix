namespace Recursivix.Fundamentals;

public class Arithmetix

{
    public static long Facto(int n)
    {
        if (n < 0)
        {
            throw new ArgumentException("Argument cannot be negative");
        }

        if (n == 0)
        {
            return 1;
        }

        return n * Facto(n - 1);
    }

    public static long Fibonacci(long n)
    {
        if (n < 0)
        {
            throw new ArgumentException($"Argument {n} cannot be negative.");
        }


        if (n == 0)
        {
            return 0;
        }

        if (n == 1)
        {
            return 1;
        }

        return Fibonacci(n - 1) + Fibonacci(n - 2);
    }

    public static long Power(long a, long n)
    {

        if (n < 0)
        {
            throw new ArgumentException("negative power is not implemented");
        }


        if (n == 0)
        {
            return 1;
        }


        if (n == 1)
        {
            return a;
        }

        try
        {

            checked
            {

                return a * Power(a, n - 1);
            }
        }
        catch (OverflowException)
        {
            throw new OverflowException("Overflow occured.");
        }
    }

    public static int InvertNumber(int n)
    {

        if (n == 0)
        {
            return 0;
        }


        return Invert(Math.Abs(n), 0, n < 0);


        int Invert(int current, int result, bool isNegative)
        {

            if (current == 0)
            {
                return isNegative ? -result : result;
            }


            return Invert(current / 10, result * 10 + (current % 10), isNegative);
        }
    }

    private static bool AuxDebugMe(int n, int divisor)
    {
        if (divisor * divisor > n) 
            return true; 

        if (n % divisor == 0) 
            return false;

        return AuxDebugMe(n, divisor + 2); 
    }

    public static bool DebugMe(int n)
    {
        if (n < 2) 
            return false;

        if (n == 2) 
            return true;

        if (n % 2 == 0) 
            return false;

        return AuxDebugMe(n, 3); 
    }

}



    


