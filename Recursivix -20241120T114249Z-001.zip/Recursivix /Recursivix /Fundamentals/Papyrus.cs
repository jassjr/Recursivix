namespace Recursivix.Fundamentals;

public class Papyrus
{
    public static string PrintSequence(uint n)
    {

        if (n == 0)
            return "0";
        return n.ToString() + ", " + PrintSequence(n - 1);
    }

    public static string DecToBin(int n)
    {

        if (n < 0)
        {
            return "-" + DecToBin(-n);
        }

        if (n == 0) return "0";
        if (n == 1) return "1";


        return DecToBin(n / 2) + (n % 2).ToString();
    }

    public static string Reverse(string str)
    {

        if (str.Length == 0 || str.Length == 1)
        {
            return str;
        }


        return Reverse(str.Substring(1)) + str[0];
    }

    public static bool IsPalindrome(string str, int left = 0, int right = -1)
    {

        if (right == -1) right = str.Length - 1;


        if (left >= right) return true;


        if (char.IsWhiteSpace(str[left])) return IsPalindrome(str, left + 1, right);


        if (char.IsWhiteSpace(str[right])) return IsPalindrome(str, left, right - 1);


        if (char.ToLower(str[left]) == char.ToLower(str[right]))
        {
            return IsPalindrome(str, left + 1, right - 1);
        }


        return false;

    }
    public static string CaesarCipher(string str, int offset) {
        return CaesarCipherRecursive(str.ToCharArray(), offset, 0);
    }

    private static string CaesarCipherRecursive(char[] arr, int offset, int index) {
        if (index >= arr.Length) {
            return "";
        }

        char currentChar = arr[index];
        char shiftedChar;

        if (currentChar >= 'A' && currentChar <= 'Z') {
            shiftedChar = (char)('A' + (currentChar - 'A' + offset + 26) % 26);
        } else if (currentChar >= 'a' && currentChar <= 'z') {
            shiftedChar = (char)('a' + (currentChar - 'a' + offset + 26) % 26);
        } else if (currentChar >= '0' && currentChar <= '9') {
            shiftedChar = (char)('0' + (currentChar - '0' + offset + 10) % 10);
        } else {
            shiftedChar = currentChar;
        }

        return shiftedChar + CaesarCipherRecursive(arr, offset, index + 1);
    }}



    
