namespace Recursivix.Fundamentals;

public class Spruce
{
    public static string BuildLine(char c, int length)
    {
        
        if (length < 0)
        {
            throw new ArgumentException($"Invalid length ({length})");
        }

       
        if (length == 0)
        {
            return "";
        }

        
        return c + BuildLine(c, length - 1);
    }
    public static string BuildSpruce(int height, char fillerChar)
    {
        if (height < 3)
        {
            throw new ArgumentException("The spruce height must be greater or equal to 3");
        }

        string BuildTree(int currentLevel, int totalHeight)
        {
            if (currentLevel == totalHeight)
                return "";

            int numSpaces = totalHeight - currentLevel - 1;
            int numFillerChars = 2 * currentLevel + 1;
            string line = BuildLine(numSpaces, numFillerChars, fillerChar) + "\n";
            return line + BuildTree(currentLevel + 1, totalHeight);
        }

        string BuildTrunk(int currentHeight, int totalHeight)
        {
            if (currentHeight == 0)
                return "";

            string trunkLine = BuildLine(totalHeight - 1, 1, fillerChar) + "\n";
            return trunkLine + BuildTrunk(currentHeight - 1, totalHeight);
        }

        return BuildTree(0, height) + BuildTrunk(height / 3, height);
    }

    private static string BuildLine(int numSpaces, int numFillerChars, char fillerChar)
    {
        string line = "";
        line = AddChars(line, ' ', numSpaces);
        line = AddChars(line, fillerChar, numFillerChars);
        return line;
    }

    private static string AddChars(string current, char character, int count)
    {
        if (count == 0)
            return current;

        return AddChars(current + character, character, count - 1);
    }

}