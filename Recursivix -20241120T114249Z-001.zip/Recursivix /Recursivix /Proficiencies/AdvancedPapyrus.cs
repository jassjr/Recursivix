namespace Recursivix.Proficiencies;

public class AdvancedPapyrus
{
    public static string Substring(string str, int begin, int length)
    {
        if (begin < 0 || length < 0  || begin + length > str.Length)
        {
            throw new ArgumentOutOfRangeException();
        }

        return ExtractSubstring(str, begin, length);
    }

    private static string ExtractSubstring(string str, int begin, int length)
    {
        if (length == 0)
        {
            return "";
        }

        return GetCharAtIndex(str, begin) + ExtractSubstring(str, begin + 1, length - 1);
    }

    private static char GetCharAtIndex(string str, int index)
    {
        if (index < 0 || index >= str.Length)
        {
            throw new ArgumentOutOfRangeException();
        }

        return str[index];
    }
    public static string Trim(string str)
    {
        
        return TrimHelper(str, 0, str.Length - 1);
    }

    private static string TrimHelper(string str, int start, int end)
    {
        
        if (start > end)
        {
            return "";
        }

        
        if (str[start] == ' ')
        {
            return TrimHelper(str, start + 1, end);
        }

        
        if (str[end] == ' ')
        {
            return TrimHelper(str, start, end - 1);
        }

      
        return BuildTrimmedString(str, start, end);
    }

    private static string BuildTrimmedString(string str, int start, int end)
    {
        
        if (start > end)
        {
            return "";
        }

      
        return str[start] + BuildTrimmedString(str, start + 1, end);
    }
    public static string GetPattern(string str, string pattern)
    {
        return GetPatternHelper(str, pattern, 0, "");
    }

    private static string GetPatternHelper(string str, string pattern, int startIndex, string result)
    {
        
        if (startIndex > str.Length - pattern.Length)
        {
            return result.TrimEnd(',');
        }

        
        if (str.IndexOf(pattern, startIndex) == startIndex)
        {
           
            result += startIndex + ",";
        }

        
        return GetPatternHelper(str, pattern, startIndex + 1, result);
    }
    public static string HanoiTower(int n)
    {
        if (n < 1)
        {
            throw new ArgumentException("Number of disks must be at least 1.");
        }

        string moves = "Moves for " + n + " disks";
        return GetMoves(n, '1', '2', '3', moves);
    }

    private static string GetMoves(int n, char source, char auxiliary, char target, string moves)
    {
        if (n == 1)
        {
            
            moves += "\n" + source + " -> " + target;
            return moves;
        }
        else
        {
            
            moves = GetMoves(n - 1, source, target, auxiliary, moves);
            
            moves += "\n" + source + " -> " + target;
           
            moves = GetMoves(n - 1, auxiliary, source, target, moves);
            return moves;
        }
    }
}