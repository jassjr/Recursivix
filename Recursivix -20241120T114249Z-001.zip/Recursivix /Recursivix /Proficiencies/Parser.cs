namespace Recursivix.Proficiencies;

public class Parser
{
    public static int BasicParse(string str)
    {
        
        if (string.IsNullOrEmpty(str))
        {
            throw new FormatException("Input cannot be empty.");
        }

        return ParseHelper(str, str.Length - 1);
    }

    private static int ParseHelper(string str, int index)
    {
        if (index < 0)
        {
            return 0;
        }

        
        char currentChar = str[index];

        
        if (currentChar < '0' || currentChar > '9')
        {
            throw new FormatException("Input contains non-digit characters.");
        }

        
        int currentDigit = currentChar - '0';

       
        return ParseHelper(str, index - 1) * 10 + currentDigit;
    } 
    public static int Parse(string str)
    {
        
        return ParseHelper(str, 0, out bool isNegative);
    }

    private static int ParseHelper(string str, int index, out bool isNegative)
    {
        
        while (index < str.Length && str[index] == ' ')
        {
            index++;
        }

        
        isNegative = false;
        if (index < str.Length)
        {
            if (str[index] == '-')
            {
                isNegative = true;
                index++;
            }
            else if (str[index] == '+')
            {
                index++;
            }
        }

        
        int result = 0;
        while (index < str.Length)
        {
            char current = str[index];

            
            if (current >= '0' && current <= '9')
            {
                result = result * 10 + (current - '0'); 
                index++;
            }
            else
            {
                
                break;
            }
        }

        
        if (isNegative)
        {
            result = -result;
        }

        
        if (result == 0 && (index < str.Length && str[index] != ' '))
        {
            throw new FormatException("Invalid input string.");
        }

        
        return result;
    }

}