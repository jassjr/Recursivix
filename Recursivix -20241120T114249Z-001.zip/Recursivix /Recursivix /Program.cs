﻿using Recursivix;
using Recursivix.Fundamentals;
using Recursivix.Proficiencies;

/*long r1 = Arithmetix.Facto(5);    // r1 == 120
long r2 = Arithmetix.Facto(0);    // r2 == 1
long r3 = Arithmetix.Facto(10);   // r3 == 3628800
Console.WriteLine((r1));
Console.WriteLine((r2));
Console.WriteLine((r3));*/

/*long r1 = Arithmetix.Fibonacci(5);    // r1 == 5
long r2 = Arithmetix.Fibonacci(0);    // r2 == 0
long r3 = Arithmetix.Fibonacci(10);   // r3 == 55
Console.WriteLine((r1));
Console.WriteLine((r2));
Console.WriteLine((r3));*/

/*long r1 = Arithmetix.Power(2, 3);     // r1 == 8
long r2 = Arithmetix.Power(0, 142);   // r2 == 0
long r3 = Arithmetix.Power(-4, 3);    // r3 == -64
long r4 = Arithmetix.Power(-5, 2);    // r4 == 25
long r5 = Arithmetix.Power(800, 0);   // r5 == 1
Console.WriteLine((r1));
Console.WriteLine((r2));
Console.WriteLine((r3));
Console.WriteLine((r4));
Console.WriteLine((r5));*/

/*int r1 = Arithmetix.InvertNumber(1234);    // r1 == 4321
int r2 = Arithmetix.InvertNumber(0);       // r2 == 0
int r3 = Arithmetix.InvertNumber(-45);     // r3 == -54
int r4 = Arithmetix.InvertNumber(777);     // r4 == 777
int r5 = Arithmetix.InvertNumber(12321);   // r5 == 12321
Console.WriteLine((r1));
Console.WriteLine((r2));
Console.WriteLine((r3));
Console.WriteLine((r4));
Console.WriteLine((r5));*/

// These examples show the expected behavior.
/*bool r1 = Arithmetix.DebugMe(15);   //r1 == False
bool r2 = Arithmetix.DebugMe(2);    //r2 == True
bool r3 = Arithmetix.DebugMe(0);    //r3 == False
Console.WriteLine((r1));
Console.WriteLine((r2));
Console.WriteLine((r3));*/

/*string r1 = Papyrus.PrintSequence(5);   // r1 == "5, 4, 3, 2, 1, 0"
string r2 = Papyrus.PrintSequence(1);   // r2 == "1, 0"
string r3 = Papyrus.PrintSequence(0);   // r3 == "0"
Console.WriteLine((r1));
Console.WriteLine((r2));
Console.WriteLine((r3));*/

/*string r1 = Papyrus.DecToBin(9);      // r1 == "1001"
string r2 = Papyrus.DecToBin(-255);   // r2 == "-11111111"
string r3 = Papyrus.DecToBin(0);      // r3 == "0"
string r4 = Papyrus.DecToBin(-1);     // r4 == "-1"
Console.WriteLine((r1));
Console.WriteLine((r2));
Console.WriteLine((r3));
Console.WriteLine((r4));*/

/*string r1 = Papyrus.Reverse("Asterix");     // r1 == "xiretsA"
string r2 = Papyrus.Reverse("Panoramix");   // r2 == "ximaronaP"
string r3 = Papyrus.Reverse("1001");        // r3 == "1001"
string r4 = Papyrus.Reverse("");            // r4 == ""
Console.WriteLine((r1));
Console.WriteLine((r2));
Console.WriteLine((r3));
Console.WriteLine((r4));*/

/*bool r1 = Papyrus.IsPalindrome("kayak");               // r1 == true
bool r2 = Papyrus.IsPalindrome("yakak");               // r2 == false
bool r3 = Papyrus.IsPalindrome("");                    // r3 == true
bool r4 = Papyrus.IsPalindrome("Never odd or even");   // r4 == true
Console.WriteLine((r1));
Console.WriteLine((r2));
Console.WriteLine((r3));
Console.WriteLine((r4));*/

/*string r1 = Papyrus.CaesarCipher("THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG", 23); // r1 == "QEB NRFZH YOLTK CLU GRJMP LSBO QEB IXWV ALD"
string r2 = Papyrus.CaesarCipher("Caesar", 2);   //r2 == "Ecguct"
Console.WriteLine((r1));
Console.WriteLine((r2));*/


/*string r1 = Spruce.BuildLine('^', 2);   // r1 == "^^"
string r2 = Spruce.BuildLine('-', 5);   // r2 == "-----"
string r3 = Spruce.BuildLine('*', 0);   // r3 == ""
Console.WriteLine((r1));
 Console.WriteLine((r2))
  Console.WriteLine((r3));
*/

/*string r1 = Spruce.BuildSpruce(4, 'a');   // r1 == "   a\n  aaa\n aaaaa\naaaaaaa\n   a\n"
string r2 = Spruce.BuildSpruce(6, '*');   // r2 == "     *\n    ***\n   *****\n  *******\n *********\n***********\n     *\n     *\n"
System.Console.Write(r2);*/

/*string r1 = AdvancedPapyrus.Substring("Assurancetourix > ACDC ?", 0, 15);        // r1 == "Assurancetourix"
string r2 = AdvancedPapyrus.Substring("The sky may fall on our heads", 4, 12);   // r2 == "sky may fall"
string r3 = AdvancedPapyrus.Substring("These ACDC are crazy!", 6, 4);            // r3 == "ACDC"
Console.WriteLine((r1));
Console.WriteLine((r2));
Console.WriteLine((r3));*/


/*string r1 = AdvancedPapyrus.Trim("    No Obelix !");   // r1 == "No Obelix !"
string r2 = AdvancedPapyrus.Trim("     ");             // r2 == ""
string r3 = AdvancedPapyrus.Trim("No changes");        // r3 == "No changes"
Console.WriteLine((r1));
Console.WriteLine((r2));
Console.WriteLine((r3));*/


/*string r1 = AdvancedPapyrus.GetPattern("an acdc atmosphere", "a");        // r1 == "0, 3, 8"
string r2 = AdvancedPapyrus.GetPattern("asterix prefixed a fix", "ix");   // r2 == "5, 12, 20"
string r3 = AdvancedPapyrus.GetPattern("piper picked pickles.", "pi");    // r3 == "0, 6, 13"
string r4 = AdvancedPapyrus.GetPattern("aaaaaa", "aa");                   // r4 == "0, 1, 2, 3, 4"
Console.WriteLine((r1));
Console.WriteLine((r2));
Console.WriteLine((r3));
Console.WriteLine((r4));*/

/*string o1 = AdvancedPapyrus.HanoiTower(1);   // o1 == "Moves for 1 disks\n1 -> 3"
string o2 = AdvancedPapyrus.HanoiTower(3);   // o2 == "Moves for 3 disks\n1 -> 3\n1 -> 2\n3 -> 2\n1 -> 3\n2 -> 1\n2 -> 3\n1 -> 3"
System.Console.Write(o2);*/

/*int r1 = Parser.BasicParse("127");          // r1 == 127
int r2 = Parser.BasicParse("0");            // r2 == 0
int r3 = Parser.BasicParse("2147483647");   // r3 == 2147483647
Console.WriteLine((r1));
Console.WriteLine((r2));
Console.WriteLine((r3));*/

/*int r1 = Parser.Parse("127");              // r1 == 127
int r2 = Parser.Parse(" 0");               // r2 == 0
int r3 = Parser.Parse("  -2147483647 ");   // r3 == -2147483647
Console.WriteLine((r1));
Console.WriteLine((r2));
Console.WriteLine((r3));*/



